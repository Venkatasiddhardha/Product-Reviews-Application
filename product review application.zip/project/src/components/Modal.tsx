import React from 'react';
import { X, Star } from 'lucide-react';
import { Product } from '../types';

interface ModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
}

export function Modal({ product, isOpen, onClose }: ModalProps) {
  if (!isOpen || !product) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-3xl w-full max-h-[90vh] overflow-y-auto" 
           onClick={(e) => e.stopPropagation()}>
        <div className="sticky top-0 bg-white p-4 border-b flex items-center justify-between">
          <h2 className="text-2xl font-bold">{product.title}</h2>
          <button
            onClick={onClose}
            className="p-1 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
        
        <div className="p-6">
          <div className="grid md:grid-cols-2 gap-8">
            <div className="aspect-square relative">
              <img
                src={product.image}
                alt={product.title}
                className="absolute inset-0 w-full h-full object-contain"
              />
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-5 h-5 ${
                        i < Math.floor(product.rating.rate)
                          ? 'fill-yellow-400 stroke-yellow-400'
                          : 'stroke-gray-300'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-gray-600">
                  {product.rating.rate} ({product.rating.count} reviews)
                </span>
              </div>
              
              <div className="text-3xl font-bold text-emerald-600">
                ${product.price.toFixed(2)}
              </div>
              
              <p className="text-gray-600">{product.description}</p>
              
              <div className="pt-4">
                <span className="inline-block px-3 py-1 bg-gray-100 text-gray-800 rounded-full text-sm font-medium">
                  {product.category}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}