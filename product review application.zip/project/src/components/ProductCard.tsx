import React from 'react';
import { Star } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onOpenModal: (product: Product) => void;
}

export function ProductCard({ product, onOpenModal }: ProductCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden transition-transform hover:scale-[1.02] cursor-pointer"
         onClick={() => onOpenModal(product)}>
      <div className="relative pb-[100%]">
        <img
          src={product.image}
          alt={product.title}
          className="absolute inset-0 w-full h-full object-contain p-4"
        />
      </div>
      <div className="p-4">
        <h3 className="text-lg font-semibold line-clamp-1 mb-2">{product.title}</h3>
        <div className="flex items-center justify-between">
          <span className="text-xl font-bold text-emerald-600">
            ${product.price.toFixed(2)}
          </span>
          <div className="flex items-center gap-1">
            <Star className="w-5 h-5 fill-yellow-400 stroke-yellow-400" />
            <span className="text-sm text-gray-600">
              {product.rating.rate} ({product.rating.count})
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}